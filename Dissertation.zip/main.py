#Importing Flask module
from flask import Flask, render_template, request, redirect, url_for, session
#Importing random module, for creating random number and finding the pre shared key 
from random import seed, random
#importing regular expressions module - for string comparisons
import re
#Importing Sqlite database tools
import sqlite3
#importing os tools
import os
#Tools for checking file name of uploaded photo and resume
from werkzeug.utils import secure_filename
#PIL module for processing image - to check the photo size
from PIL import Image
#Cryptography module, to encrypt password
from cryptography.fernet import Fernet
#Datetime module for time stamping twitter query
from datetime import date
#Creating an ML model
#runfile('Generate.py')
#Importing the Candidate Character predcition program
from Predict import *
import jinja2
import pdfkit
import time


#For Photo Upload
UPLOAD_FOLDER = 'static/files/'
ALLOWED_EXTENSIONS = {'doc', 'docx', 'jpg', 'jpeg', 'png'}



def getpdf(accn, attr_1,  attr_2, attr_3,  attr_4, attr_1_per, attr_2_per, attr_3_per, attr_4_per, chara, uniq_id, pro_pic, pic):
    templateLoader = jinja2.FileSystemLoader(searchpath="./")
    templateEnv = jinja2.Environment(loader=templateLoader)
    TEMPLATE_FILE = "templates/emp_query_det_template.html"
    template = templateEnv.get_template(TEMPLATE_FILE)

    ts = time.time()
    st = time.ctime(ts)
    out = template.render(account=accn, attr_1=attr_1,   attr_2=attr_2,  attr_3=attr_3,  attr_4=attr_4,  attr_1_per=attr_1_per, attr_2_per=attr_2_per, attr_3_per=attr_3_per, attr_4_per=attr_4_per, chara=chara, pro_pic=pro_pic, st=st, pic=pic)
    temp_file_name = uniq_id + ".html"
    html_file=open(temp_file_name, 'w')
    html_file.write(out)
    html_file.close()
    options = {"enable-local-file-access":""}
    file_name = "static/files/" + uniq_id + ".pdf"
    pdfkit.from_file(temp_file_name, file_name, options=options)
    os.remove(temp_file_name)
    return file_name

#Method for checking proper file extension format 
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

#Method for changing filename of photo and resume to username
def can_file_name(filename,usrname):
    length=len(filename)
    count = 0
    for i in filename:
        if i != '.':
            count+=1
        else:
            break

    return usrname + filename[(count-length):]

#Method for listing mbti characters
def pers_assess(mbti):
    if mbti == 'ENFJ':
        str1 = "ENFJ types are intelligent, warm, idealistic, charismatic, creative, social and are able to thrive in many diverse roles, at any level of seniority."
    elif mbti == 'ISTJ':
        str1 = "ISTJ types make stereotypical, classic, hard-working, dutiful employees. In whatever position they are, seeks structure, clearly defined rules, and respect for authority and hierarchy."
    elif mbti == 'INFJ':
        str1 = "INFJ types are clever and inspired, they seek the knowledge that, what they are doing has a meaning, in everything they do."
    elif mbti == 'INTJ':
        str1 = "INTJ types are independant, capable of tackling various problems intellectually and can execute work with little outside interference."
    elif mbti == 'ISTP':
        str1 = "ISTP types seeks a sense of unpredictability and excitement in their work. "
    elif mbti == 'ESFJ':
        str1 = "ESFJ types thrive on social order and harmony, and use their warmth and social intelligence to make sure that each person knows their responsibilities and is able to get done what needs to get done."
    elif mbti == 'INFP':
    	str1 = "INFP types value harmony and often needs an emotional and moral connection to their work."
    elif mbti == 'ESFP':
    	str1 = "ESFP types have the inate desire to make the working environment as friendly and enjoyable as possible."
    elif mbti == 'ENFP':
    	str1 = "ENFP types always exploit the chance to explore new ideas, and the chance to conduct that exploration alongside other people who share their excitement."
    elif mbti == 'ESTP':
        str1 = "ESTP types are often boisterous and spontaneous, they exhibit an innate desire for exploring fun in everything they do."
    elif mbti == 'ESTJ':
        str1 = "ESTJ types have clear and consistent tendencies, and these are especially visible in the workplace."
    elif mbti == 'ENTJ':
        str1 = "ENTJ types are nicknamed Commanders, their efficiency and clarity in communication are valueable, their leadership qualities are admirable, and their ability to simply get things done is unrivaled."
    elif mbti == 'INTP':
        str1 = "INTP types have an innate desire for solitude, and often requires intellectual stimulation. They derive satisfaction from the final piece of a puzzle by clicking each into place."
    elif mbti == 'ISFJ':
    	str1 = "ISFJ types are custom fit into any job role. Whether it be subordinates, colleagues or managers, they share the goal of putting good service and dedication above everything else. "
    elif mbti == 'ENTP':
        str1 = "ENTP types often offer new solutions and ideas regardless of their positions."
    else:
        str1 = "ISFP types are spontaneous, charming, and genuinely fun people to be around. They just want a chance to express those natural qualities, and to know that their efforts are appreciated."
    return str1

#Method for checking whether twitter account details are up to date
def chk_update(ts):
    up_date=0
    t_s=re.split(r'-',ts)
    ts_ref=re.split(r'-',str(date.today()))
    if int(t_s[0]) < int(ts_ref[0]):
        up_date=1
    elif int(t_s[1]) < int(ts_ref[1]):
        up_date=1
    elif int(ts_ref[2])-int(t_s[2]) >= 14:
        up_date=1
    return up_date

#Method for updating assessed attributes in database
def update_attrib_db(username,twit):
    pred = twit_predict(twit)
    if pred[0] == 'Y':
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            ts=date.today()
            cur.execute("UPDATE Candidate SET Can_Attrib_1 = ? WHERE Can_User = ?",(pred[1], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_1_per = ? WHERE Can_User = ?",(pred[2], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_2 = ? WHERE Can_User = ?",(pred[3], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_2_per = ? WHERE Can_User = ?",(pred[4], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_3 = ? WHERE Can_User = ?",(pred[5], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_3_per = ? WHERE Can_User = ?",(pred[6], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_4 = ? WHERE Can_User = ?",(pred[7], username,))
            cur.execute("UPDATE Candidate SET Can_Attrib_4_per = ? WHERE Can_User = ?",(pred[8], username,))
            cur.execute("UPDATE Candidate SET Can_Char = ? WHERE Can_User = ?",(pred[9], username,))
            cur.execute("UPDATE Candidate SET Can_Per = ? WHERE Can_User = ?",(pred[10], username,))
            cur.execute("UPDATE Candidate SET Can_Ts = ? WHERE Can_User= ?",(ts,username))
            con.commit()
        return 'Updation Successful!'
    else:
        return "Invalid Twitter Account!"
  
#Secret Key for encrypting password of both Employers and Candidates
key = Fernet.generate_key()

#Starting Flask
app = Flask(__name__)

# Change this to your secret key (can be anything, it's for extra protection)
app.secret_key = '123456'

#Defining the upload folder for photos and resumes
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

        
# http://localhost:5000/index.html
@app.route('/', methods=['GET', 'POST'])
def login():
        
    # Output message if something goes wrong...
    msg = '' 
    # Checks if "username", "password" and "type" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'type' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        type = request.form['type']
        # Check whether Employer account exists in SQLite database
        if type == 'Employer':
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (username, ))
                # Fetch one record and return result
                account = cur.fetchone()
                # If account exists in accounts table in database
                if account:
                    key = account[8].encode()
                    cipher_suite = Fernet(key)
                    chk_pass = cipher_suite.decrypt(account[4])
                    if chk_pass.decode() == password:
                        # Create session data, we can access this data from other pages
                        session['loggedin'] = True
                        session['username'] = username
                        session['type'] = type
                        session['fstname'] = account[2]
                        session['lstname'] = account[3]
                        session['comp'] = account[7]
                        # Redirect to home page
                        return redirect(url_for('emp_home'))
                    else:
                        # Account doesnt exist or username/password incorrect
                        msg = 'Incorrect username/password!'
                else:
                    # Account doesnt exist or username/password incorrect
                    msg = 'Incorrect username/password!'
                    
        # Check whether Candidate account exists in SQLite database
        if type == 'Candidate':
            
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (username, ))
                # Fetch one record and return result
                account = cur.fetchone()
                # If account exists in accounts table in out database
                if account:
                    key = account[19].encode()
                    cipher_suite = Fernet(key)
                    chk_pass = cipher_suite.decrypt(account[4])
                    if chk_pass.decode() == password:
                        # Create session data, we can access this data from other pages
                        session['loggedin'] = True
                        session['username'] = username
                        session['type'] = type
                        session['fstname'] = account[2]
                        session['lstname'] = account[3]
                        # Redirect to home page
                        return redirect(url_for('can_home'))
                    else:
                        # Account doesnt exist or username/password incorrect
                        msg = 'Incorrect username/password!'                       
                else:
                    # Account doesnt exist or username/password incorrect
                    msg = 'Incorrect username/password!'

    # Show the login form with message (if any)
    return render_template('index.html', msg=msg)


# http://localhost:5000/logout - this method will be do the logout action
@app.route('/logout')
def logout():
   # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))

# http://localhost:5000/emp_register - this will be the Employer registration page, we need to use both GET and POST requests
@app.route('/emp_register', methods=['GET', 'POST'])
def emp_register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password"  "email" "mobile" etc. POST requests exist (user submitted form)
    if request.method == 'POST' and 'fstname' in request.form and 'lstname' in request.form and 'username' in request.form and 'password' in request.form and 'email' in request.form and 'Mobile' in request.form:
        # Create variables for easy access
        fstname = request.form['fstname']
        lstname = request.form['lstname']
        user = request.form['username']
        cipher_suite = Fernet(key)
        pas = cipher_suite.encrypt((request.form['password']).encode())
        mob = request.form['Mobile']
        email = request.form['email']
        comp = request.form['comp']
        agree = request.form['agree']
        # Check if account exists using SQLite
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (user,))
            account = cur.fetchone()
            # If account exists show error and validation checks
            if account:
                msg = 'Account already exists!'
            elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
                msg = 'Invalid email address!'
            elif not re.match(r'[A-Za-z0-9]+', user):
                msg = 'Username must contain only characters and numbers!'
            elif len(str(mob)) != 10:
                msg = 'Invalid Mobile Number'
            elif not user or not pas or not email or not comp or not mob:
                msg = 'Please fill out the form!'
            elif agree == "N":
                msg = 'To register, please accept the terms and conditions..'
            else:
                # Account doesnt exists and the form data is valid, now insert new account into accounts table
                with sqlite3.connect("PTP.db") as con:
                    cur = con.cursor()
                    cur.execute("INSERT INTO Employer (Emp_Fname, Emp_Lname, Emp_User, Emp_Pass, Emp_Mob, Emp_email, Emp_Comp, cipher_key) VALUES (?,?,?,?,?,?,?,?)",(fstname,lstname,user,pas,mob,email,comp,key.decode()))
                    con.commit()
                    msg = 'You have successfully registered!'

    # Remove session data, this will log the user out
    session.pop('loggedin', None)
    session.pop('username', None)
    # Show registration form with message (if any)
    return render_template('emp_register.html', msg=msg)



# http://localhost:5000/can_register - this will be the Candidate registration page, we need to use both GET and POST requests
@app.route('/can_register', methods=['GET', 'POST'])
def can_register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password"  "email" "mobile" POST requests exist (user submitted form)
    if request.method == 'POST' and 'fstname' in request.form and 'lstname' in request.form and 'username' in request.form and 'pwd_fst' in request.form and 'pwd_snd' in request.form and 'email' in request.form:
        # Create variables for easy access
        fstname = request.form['fstname']
        lstname = request.form['lstname']
        username = request.form['username']
        email = request.form['email']
        pwd_fst = request.form['pwd_fst']
        pwd_snd = request.form['pwd_snd']
        agree = request.form['agree']
        
        # Check if account exists using SQLite
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (username,))
            account = cur.fetchone()
            # If account exists show error and validation checks
            if account:
                msg = 'Account already exists!'
            elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
                msg = 'Invalid email address!'
            elif not re.match(r'[A-Za-z0-9]+', username):
                msg = 'Username must contain only characters and numbers!'
            elif pwd_fst != pwd_snd:
                msg = 'Passwords don\'t match!!'
            elif not fstname or not lstname or not username or not pwd_fst or not pwd_snd or not email:
                msg = 'Please fill out the form!'
            elif agree == "N":
                msg = 'To register with us, the terms and conditions are to be agreed with..'
            else:
                # Account doesn't exists and the form data is valid, now insert new account into accounts table
                cipher_suite = Fernet(key)
                password = cipher_suite.encrypt(pwd_fst.encode())           
                #Intitializing the values for Profile Photo and Resume
                Pho = Res = ""
                with sqlite3.connect("PTP.db") as con:
                    cur = con.cursor()
                    cur.execute("INSERT INTO Candidate (Can_Fname, Can_Lname, Can_User, Can_Pass, Can_Mail, Can_Pho, Can_Res, cipher_key) VALUES (?,?,?,?,?,?,?,?)",(fstname, lstname, username, password, email, Pho, Res, key.decode()))
                    cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (username,))
                    for_rand = cur.fetchone()
                    seed(for_rand[0])
                    PSK=int(random()*10000//1)
                    cur.execute("UPDATE Candidate SET Can_PSK = ? WHERE Can_User = ?",(PSK, username))
                    con.commit()
                    msg = 'You have successfully registered!'


    # Show registration form with message (if any)
    return render_template('can_register.html', msg=msg)

# http://localhost:5000/emp_home - this will be the Employer home page, only accessible for loggedin users
@app.route('/emp_home', methods = ['GET', 'POST'])
def emp_home():
    # Check if user is loggedin
    if 'loggedin' in session:
        msg=""
        
        if request.method == 'POST' and 'uniq_id' in request.form and 'psk' in request.form:
            uniq_id = request.form['uniq_id']
            psk = request.form['psk']
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                cur.execute('SELECT * FROM Candidate WHERE Can_User = ? AND Can_PSK = ?', (uniq_id, int(psk)))
                # Fetch one record and return result
                acc = cur.fetchone()

                # If account exists in accounts table in out database
                if acc:
                    msg='Details fetched Successfully'
                    update = chk_update(acc[10])
                    attr_1_pic = "static\\" + str(acc[11])+".png"
                    attr_2_pic = "static\\" + str(acc[13])+".png"
                    attr_3_pic = "static\\" + str(acc[15])+".png"
                    attr_4_pic = "static\\" + str(acc[21])+".png"
                    attr_1_per = acc[12]*10 
                    attr_2_per = acc[14]*10
                    attr_3_per = acc[20]*10
                    attr_4_per = acc[22]*10
                    if update == 1:
                        update_attrib_db(acc[1],acc[8])
                        cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (uniq_id,))
                        accn = cur.fetchone()
                        chara = pers_assess(accn[23])
                        if accn[17]:
                            pro_pic = "static/files/" + accn[17]
                        else:
                            pro_pic = "static/files/default.jpg"
                        pic = "static/" + accn[23] + ".jpg"
                        filename = getpdf(accn, attr_1_pic,  attr_2_pic, attr_3_pic,  attr_4_pic, attr_1_per, attr_2_per, attr_3_per, attr_4_per, chara, uniq_id, pro_pic, pic)
                        return render_template('emp_query_det.html', account=accn, attr_1=attr_1_pic,  attr_2=attr_2_pic,  attr_3=attr_3_pic,  attr_4=attr_4_pic, attr_1_per=attr_1_per, attr_2_per=attr_2_per, attr_3_per=attr_3_per, attr_4_per=attr_4_per, comp=session['comp'], msg=msg, chara=chara, filename=filename, pro_pic=pro_pic, pic=pic)
                        
                    else:
                        chara = pers_assess(acc[23])
                        if acc[17]:
                            pro_pic = "static/files/" + acc[17]
                        else:
                            pro_pic = "static/files/default.jpg"
                        pic = "static/" + acc[23] + ".jpg"
                        filename = getpdf(acc, attr_1_pic,  attr_2_pic, attr_3_pic,  attr_4_pic, attr_1_per, attr_2_per, attr_3_per, attr_4_per,chara, uniq_id, pro_pic, pic)
                        return render_template('emp_query_det.html', account=acc, attr_1=attr_1_pic,   attr_2=attr_2_pic,  attr_3=attr_3_pic,  attr_4=attr_4_pic, attr_1_per=attr_1_per, attr_2_per=attr_2_per, attr_3_per=attr_3_per, attr_4_per=attr_4_per, comp=session['comp'], msg=msg, chara=chara, filename=filename, pro_pic=pro_pic, pic=pic)
                        
                else:
                    msg='Incorrect Credentials'
                    return render_template('emp_home.html', msg=msg, Fstname=session['fstname'], Lstname=session['lstname'], comp=session['comp'])
        # User is loggedin show them the home page
        return render_template('emp_home.html', Fstname=session['fstname'], Lstname=session['lstname'], comp=session['comp'])
    # User is not loggedin redirect to login page
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# http://localhost:5000/can_home - this will be the Candidate home page, only accessible for loggedin users
@app.route('/can_home')
def can_home():
    # Check if user is loggedin
    if 'loggedin' in session:
        # We need all the account info for the user so we can display it on the profile page
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
            account = cur.fetchone()
            # User is loggedin show them the home page
            return render_template('can_home.html', account=account, img="static/files/"+account[17], res="static/files/"+account[18])
    # User is not loggedin redirect to login page
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# http://localhost:5000/emp_profile - this will be the Employer profile page, only accessible for loggedin users
@app.route('/emp_profile')
def emp_profile():
    # Check if user is loggedin
    if 'loggedin' in session:
        # We need all the account info for the user so we can display it on the profile page
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (session['username'],))
                account = cur.fetchone()
                # Show the profile page with account info
                return render_template('emp_profile.html', account=account,type=session['type'], comp=session['comp'])
    # User is not loggedin redirect to login page
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))
            
# http://localhost:5000/emp_profile_update - this will be the Employer profile updation page, only accessible for loggedin users
@app.route('/emp_profile_update', methods=['GET', 'POST'])
def emp_profile_update():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (session['username'],))
            account = cur.fetchone()
        msg = ''
        # Check if "username", "password"  "email" "mobile" etc. POST requests exist (user submitted form)
        if request.method == 'POST':
            # Create variables for easy access
            mob = request.form['mobile']
            email = request.form['email']
            # Check which elements are present in the form and update those
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                if mob:
                    if len(str(mob)) != 10:
                        msg = 'Invalid Mobile Number'
                        return render_template('emp_profile_update.html',account=account, msg=msg)
                    else:
                        cur.execute("UPDATE Employer SET Emp_Mob = ? WHERE Emp_User= ?",(mob,session['username']))
                        msg = 'Updation Sucessful!'
                if email:
                    cur.execute("UPDATE Employer SET Emp_email = ? WHERE Emp_User= ?",(email,session['username']))                    
                    msg = 'Updation Sucessful!'
                
                cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (session['username'],))
                account = cur.fetchone()
        return render_template('emp_profile_update.html',account=account, msg=msg, comp=session['comp'])
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# http://localhost:5000/can_profile_update - this will be the Candidate profile updation page, only accessible for loggedin users
@app.route('/can_profile_update', methods=['GET', 'POST'])
def can_profile_update():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
            account = cur.fetchone()
        msg = ''
        # Check if "username", "password"  "email" "mobile" etc. POST requests exist (user submitted form)
        if request.method == 'POST':
            # Create variables for easy access
            mob = request.form['mobile']
            email = request.form['email']
            twit = request.form['twit']
            dob = request.form['dob']
            # Check which elements are present in the form and update those
            with sqlite3.connect("PTP.db") as con:
                cur = con.cursor()
                if mob:
                    if len(str(mob)) != 10:
                        msg = 'Invalid Mobile Number'
                        return render_template('can_profile_update.html',account=account, msg=msg)
                    else:
                        cur.execute("UPDATE Candidate SET Can_Mob = ? WHERE Can_User= ?",(mob,session['username']))
                        msg = 'Updation Sucessful!'
                if email:
                    cur.execute("UPDATE Candidate SET Can_Mail = ? WHERE Can_User= ?",(email,session['username']))                    
                    msg = 'Updation Sucessful!'
                if dob:
                    cur.execute("UPDATE Candidate SET Can_Dob = ? WHERE Can_User= ?",(dob,session['username']))                    
                    msg = 'Updation Sucessful!'
                con.commit()
                if twit:
                    if twit[0] != '@':
                        msg = 'Invalid Twitter Handle'
                        return render_template('can_profile_update.html',account=account, msg=msg)
                    else:
                        msg = update_attrib_db(session['username'],twit)
                        if msg == 'Updation Successful!':
                            with sqlite3.connect("PTP.db") as con:
                                cur = con.cursor()
                                cur.execute("UPDATE Candidate SET Can_Twit = ? WHERE Can_User= ?",(twit,session['username']))
                                cur.execute("SELECT Can_PSK FROM Candidate WHERE Can_User = ?",(session['username'],))
                                old_PSK = cur.fetchone()
                                seed(old_PSK)
                                new_PSK = int(random()*10000//1)
                                cur.execute("UPDATE Candidate SET Can_PSK = ? WHERE Can_User = ?",(new_PSK, session['username'],))
                                con.commit()
                        
                with sqlite3.connect("PTP.db") as con:
                    cur = con.cursor()
                    cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
                    account = cur.fetchone()
        return render_template('can_profile_update.html',account=account, msg=msg)
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# http://localhost:5000/can_photo_upload - this will be the page from which Candidate will be able to update photo, only accessible for loggedin users
@app.route('/can_photo_upload', methods=['GET', 'POST'])
def can_photo_upload():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
            account = cur.fetchone()
        msg = ''
        # Settings for uploading Photos

        if request.method == 'POST' and 'photo' in request.files:
            file = request.files['photo']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_name = can_file_name(filename,session['username'])
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], file_name))
                img_loc = 'static/files/' + file_name
                Img = Image.open(img_loc)
                width, height = Img.size
                if width > 200 or height > 300:
                    msg = 'File size higher than specification'
                    #return render_template('can_photo_upload.html',account=account, msg=msg)  
                else:
                    with sqlite3.connect("PTP.db") as con:
                        cur = con.cursor()
                        cur.execute('UPDATE Candidate SET Can_Pho = ? WHERE Can_User = ?', (file_name, session['username'],))
                        con.commit()
                        msg = "File Uploaded Sucessfully!"
                
                return render_template('can_photo_upload.html',account=account, msg=msg)  
        return render_template('can_photo_upload.html',account=account, msg=msg)    
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# http://localhost:5000/can_resume_upload - this will be the page from which Candidate will be able to update resume, only accessible for loggedin users
@app.route('/can_resume_upload', methods=['GET', 'POST'])
def can_resume_upload():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
            account = cur.fetchone()
        msg = ''
        # Settings for uploading Photos

        if request.method == 'POST' and 'resume' in request.files:
            file = request.files['resume']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_name = can_file_name(filename,session['username'])
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], file_name))
                with sqlite3.connect("PTP.db") as con:
                    cur = con.cursor()
                    cur.execute('UPDATE Candidate SET Can_Res = ? WHERE Can_User = ?', (file_name, session['username'],))
                    con.commit()
                    msg = "File Uploaded Sucessfully!"
                
                return render_template('can_resume_upload.html',account=account, msg=msg)  
        return render_template('can_resume_upload.html',account=account, msg=msg)
    session.pop('loggedin', None)
    session.pop('username', None)    
    return redirect(url_for('login'))

# http://localhost:5000/can_chg_pwd - this will be the page from which Candidate will be able to change password, only accessible for loggedin users
@app.route('/can_chg_pwd', methods=['GET', 'POST'])
def can_chg_pwd():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Candidate WHERE Can_User = ?', (session['username'],))
            account = cur.fetchone()
            key = account[19].encode()
            cipher_suite = Fernet(key)
            chk_pass = cipher_suite.decrypt(account[4])
            curr_pw_stored = chk_pass.decode()
        msg = ''
        # Settings for uploading Photos

        if request.method == 'POST' and 'curr_pwd' in request.form and 'new_pwd_1' in request.form and 'new_pwd_2' in request.form:
            curr_pw = request.form['curr_pwd']
            new_pw_1 = request.form['new_pwd_1']
            new_pw_2 = request.form['new_pwd_2']
            if curr_pw:
                if curr_pw != curr_pw_stored:
                    msg = "Current Password you have entered is Wrong"
                    session.pop('loggedin', None)
                    session.pop('username', None)
                    return redirect(url_for('login'))
                elif new_pw_1 != new_pw_2:
                    msg = "New Passwords don't match"
                    return render_template('can_chg_pwd.html',account=account, msg=msg)  
                else:
                    cipher_suite = Fernet(key)
                    new_pw_1_enc = cipher_suite.encrypt(new_pw_1.encode())      
                    cur.execute('UPDATE Candidate SET Can_Pass = ? WHERE Can_User = ?', (new_pw_1_enc, session['username'],))
                    cur.execute('UPDATE Candidate SET cipher_key = ? WHERE Can_User = ?', (key.decode(), session['username'],))
                    con.commit()
                    msg = "Password changed Successfully!"
            else:
                msg = "Please enter all fields!"            
        return render_template('can_chg_pwd.html',account=account, msg=msg)    
    return redirect(url_for('login'))

#http://localhost:5000/emp_chg_pwd - this will be the page from which Employer will be able to change password, only accessible for loggedin users
@app.route('/emp_chg_pwd', methods=['GET', 'POST'])
def emp_chg_pwd():
    if 'loggedin' in session:
        with sqlite3.connect("PTP.db") as con:
            cur = con.cursor()
            cur.execute('SELECT * FROM Employer WHERE Emp_User = ?', (session['username'],))
            account = cur.fetchone()
            key = account[8].encode()
            cipher_suite = Fernet(key)
            chk_pass = cipher_suite.decrypt(account[4])
            curr_pw_stored = chk_pass.decode()
        msg = ''
        # Settings for uploading Photos

        if request.method == 'POST' and 'curr_pwd' in request.form and 'new_pwd_1' in request.form and 'new_pwd_2' in request.form:
            curr_pw = request.form['curr_pwd']
            new_pw_1 = request.form['new_pwd_1']
            new_pw_2 = request.form['new_pwd_2']
            if curr_pw and new_pw_1 and new_pw_2:
                if curr_pw != curr_pw_stored:
                    msg = "Current Password you have entered is Wrong"
                    session.pop('loggedin', None)
                    session.pop('username', None)
                    return redirect(url_for('login'))
                elif new_pw_1 != new_pw_2:
                    msg = "New Passwords don't match"
                    return render_template('emp_chg_pwd.html',account=account, msg=msg)  
                else:
                    cipher_suite = Fernet(key)
                    new_pw_1_enc = cipher_suite.encrypt(new_pw_1.encode())                    
                    cur.execute('UPDATE Employer SET cipher_key = ? WHERE Emp_User = ?', (key.decode(), session['username']))
                    cur.execute('UPDATE Employer SET Emp_Pass = ? WHERE Emp_User = ?', (new_pw_1_enc, session['username']))
                    con.commit()
                    msg = "Password changed Successfully!"
            else:
                msg = "Please enter all fields"
        return render_template('emp_chg_pwd.html',account=account, msg=msg, comp=session['comp'])    
    return redirect(url_for('login'))


if __name__ == '__main__':
   app.run(debug = True, use_reloader=False)